package br.com.fatec.lista1.errormessages;

public class HistoricErrors {
    public void HistoryAlreadyContains() {
        System.out.println("ERROR: O histórico já contém esta mesma compra.");
    }
}
